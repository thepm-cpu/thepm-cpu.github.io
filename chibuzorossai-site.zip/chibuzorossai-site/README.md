# chibuzorossai.com

Personal site of Chibuzor Ossai, DevOps and cloud engineer and mechanical engineer.

One static page (`index.html`) with its images and two CVs, served by GitHub Pages.
No build step: change a file, commit, and the site updates in about a minute.
